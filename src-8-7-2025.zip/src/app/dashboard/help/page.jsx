import React from 'react'
import HelpPage from './HelpPage'

function page() {
  return (
    <HelpPage />
  )
}

export default page