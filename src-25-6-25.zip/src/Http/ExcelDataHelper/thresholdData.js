
export const thresholdDataField = [
    "Quantity Base Discount Type",
    "Threshold Level 1 Unit",
    "Threshold Level 1 Discount",

    "Threshold Level 2 Unit",
    "Threshold Level 2 Discount",

    "Threshold Level 3 Unit",
    "Threshold Level 3 Discount",

    "Threshold Level 4 Unit",
    "Threshold Level 4 Discount",

    "Threshold Level 5 Unit",
    "Threshold Level 5 Discount",
]

export const thresholdFieldDataTypes = [
     "Select value from dropdown", // "Quantity Base Discount Type",
    "Number", // "Threshold Levels1 Unit",
    "Numerical", // "Threshold Levels1 Discount",

    "Number", // "Threshold Levels2 Unit",
    "Numerical", // "Threshold Levels2 Discount",

    "Number", //  "Threshold Levels3 Unit",
    "Numerical", // "Threshold Levels3 Discount",

    "Number", // "Threshold Levels4 Unit",
    "Numerical", // "Threshold Levels4 Discount",

    "Number", // "Threshold Levels5 Unit",
    "Numerical", // "Threshold Levels5 Discount",
]


export const thresholdExampleField = [
    "Optional", // "Quantity Base Discount Type",
    "Optional", //  "Threshold Levels1 Unit",
    "Optional", //  "Threshold Levels1 Discount",

    "Optional", //  "Threshold Levels2 Unit",
    "Optional", //  "Threshold Levels2 Discount",

    "Optional", //  "Threshold Levels3 Unit",
    "Optional", //  "Threshold Levels3 Discount",

    "Optional", //  "Threshold Levels4 Unit",
    "Optional", //  "Threshold Levels4 Discount",

    "Optional", //  "Threshold Levels5 Unit",
    "Optional", //  "Threshold Levels5 Discount",
]


export const thresholdDetailsInField = [
    "", // "Quantity Base Discount Type",
    "", //  "Threshold Levels1 Unit",
    "", //  "Threshold Levels1 Discount",

    "", //  "Threshold Levels2 Unit",
    "", //  "Threshold Levels2 Discount",

    "", //  "Threshold Levels3 Unit",
    "", //  "Threshold Levels3 Discount",

    "", //  "Threshold Levels4 Unit",
    "", //  "Threshold Levels4 Discount",

    "", //  "Threshold Levels5 Unit",
    "", //  "Threshold Levels5 Discount",
]


