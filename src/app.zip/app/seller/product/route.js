


export async function POST(request) {
    const {_id} = await request.json();
}