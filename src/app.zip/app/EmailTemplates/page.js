
import React from 'react'
import SellerLoginEmail from './SellerLoginEmail'

function page() {
  return (
    <SellerLoginEmail />
  )
}

export default page