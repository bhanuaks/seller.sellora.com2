

// export const exportProductField = [ 
//           "Category",
//           "SubCategory",
//           "ChildCategory",
//           "Brand Name",
//           "Product Name",
//           "Product Description",
//           "Key Features",
//           "Search Keywords",
//           "Target Gender",
//           "Age Range Description",
//           "Color",
//           "Size",
//           "Number Of Item",
//           "Material",
//           "Style",
//           "Pattern",
//           "UnitCount",
//           "UnitCount Type",
//           "Item Type Name",
//           "Recommended Use",
//           "Model Name",
//           "Model Number",
//           "ManufacturePart Number",
//           "Country Of Origin",
//           "Manufacturer",
//           "Packer Contact Information",
//           "Importer Details",
//           "Tax Code",
//           "Tax Rate",
//           "Fullfilment By",
//           "Shipping Provider",
//           "ProductLength",
//           "Product LengthUnit", 
//           "Product Width",
//           "Product Width Unit",
    
//           "Product Height",
//           "Product Height Unit",
    
//           "Product Weight",
//           "Product Weight Unit",
    
//           "Package Length",
//           "Package LengthUnit",
    
//           "Package Width",
//           "Package Width Unit",
    
//           "Package Height",
//           "Package Height Unit",
    
//           "Package Weight",
//           "Packag eWeight Unit",
    
//           "main_image",
//           "Image_1",
//           "Image_2",
//           "Image_3",
//           "Image_4",
//           "Image_5",
//           "Image_6",
//           "Image_7",
    
     
// ];




// export const exportVariantField = [  
    
//           // variant Fields 
//           "Product Id",
//           "ProductId Type",
//           "SKU",
//           "Listing Status",
//           "MSRP",
//           "Consumer Sale Price",
//           "Business Sale Price",
//           "Stock",
//           "Currency",
//           "Condition Type",
//           "Expire Date", 
//           "variantImage",
//           "variant_image_1",
//           "variant_image_2",
//           "variant_image_3",
//           "variant_image_4",
//           "variant_image_5",
//           "variant_image_6",
//           "variant_image_7",
// ];







// export const productFieldDataTypes = [ 
//           "Text",
//           "Text",
//           "Text",
//           "Single Text",
//           "Single Text",
//           "Single Text",
//           "Key Features",
//           "Multi Text and null",
//           "Select value from dropdown",
//           "Select value from dropdown",
//           "Select value from dropdown",
//           "SingleText",
//           "Numeric",
//           "Single-Text",
//           "Single-Text",
//           "Single-Text",
//           "numberic",
//           "Single-Text",
//           "Single-Text",
//           "Single-Text",
//           "Single-Text",
//           "Single-Text",
//           "Single-Text",
//           "Single-Text",
//           "Single-Text",
//           "Single-Text",
//           "Single-Text",
//           "Single-Text",
//           "numeric",
//           "Single-Text",
//           "Single-Text",
//           "Single-Text",
//           "Select value from dropdown", 
//           "Single-Text",
//           "Select value from dropdown",
    
//           "Single-Text",
//           "Select value from dropdown",
    
//           "Single-Text",
//           "Select value from dropdown",
    
//           "Single-Text",
//           "Select value from dropdown",
    
//           "Single-Text",
//           "Select value from dropdown",
    
//           "Single-Text",
//           "Select value from dropdown",
    
//           "Single-Text",
//           "Select value from dropdown",
    
//           "Single-Text",
//           "image url",
//           "image url",
//           "image url",
//           "image url",
//           "image url",
//           "image url",
//           "image url",
    
     
// ];



// export const variantFieldDataTypes = [ 
         
//           // variant Fields 
//           "Single-Text",
//           "Single-Text",
//           "Single-Text",
//           "Single-Text",
//           "Single-Text",
//           "Single-Text",
//           "Single-Text",
//           "numeric",
//           "Select from dropdown",
//           "Single-Text",
//           "date", 
//           "Select value from dropdown",
//           "url",
//           "url",
//           "url",
//           "url",
//           "url",
//           "url",
//           "url",
// ];



// export const fillExampleField = [ 
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           " ",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "", 
//           "",
//           "",
    
//           "",
//           "",
    
//           "",
//           "",
    
//           "",
//           "",
    
//           "",
//           "",
    
//           "",
//           "",
    
//           "",
//           "",
    
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
     
// ];



// export const variantFillExampleField = [  
//           // variant Fields 
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "",
//           "", 
//           "",
//           "https://seller.sellora.com/uploads/product/main_image/medium//Streax_main_20250410061840668..jpg",
//           "https://seller.sellora.com/uploads/product/main_image/medium//Streax_main_20250410061840668..jpg",
//           "https://seller.sellora.com/uploads/product/main_image/medium//Streax_main_20250410061840668..jpg",
//           "https://seller.sellora.com/uploads/product/main_image/medium//Streax_main_20250410061840668..jpg",
//           "https://seller.sellora.com/uploads/product/main_image/medium//Streax_main_20250410061840668..jpg",
//           "https://seller.sellora.com/uploads/product/main_image/medium//Streax_main_20250410061840668..jpg",
//           "https://seller.sellora.com/uploads/product/main_image/medium//Streax_main_20250410061840668..jpg",
// ];






// export const detailsInField = [ 
//           "Category",
//           "SubCategory",
//           "ChildCategory",
//           "Brand refers to a type of product manufactured by a company under a particular name.",
//           "Title refers to the product title that will appear on the product page. Highlight the brand name and product features that will attract buyers.",
//           "Please write few lines describing your product along with a list of products that are compatible with this product. Description is limited to 10000 characters (including spaces). It should not include any hyperlinks, additional offers, or promotion text.",
//           "Key Features refers to the defining features of a product that can be highlighted on the website.",
//           "Search Keywords refers to the words which the customer might use to find a product. These keywords are tagged to the product and when the buyer searches with the appropriate search word(s), the nearest appropriate product is retrieved and displayed on Sellora website. The search output is also based on multiple other factors such as Product Quality, Pricing, etc. Please enter a maximum of 5 keywords for this purpose.",
//           "Target Gender",
//           "Age Range Description",
//           `Color refers to the shade of the product as specified by the brand on the label or sales package. The value 'Multicolor' should be used if the product features a mix of three or more prominent colors. Possible values include 'Red,' 'Black,' etc `,
//           `Size refers to the size of the product as mentioned by the brand.`,
//           "Number Of Item",
//           "Material",
//           `Style Code is an alphanumeric code which is given to a product and can be found on the tag or packaging. Style Code remains the same for all Size variants and changes for all Color variants. For example, a red colored product that comes in three different sizes will have the same Style Code.`,
//           `Pattern refers to a repeated decorative sketch that is printed or engraved on a product.`,
//           "UnitCount",
//           "UnitCount Type",
//           "Item Type Name",
//           "Recommended Use",
//           "Model Name",
//           "Model Number",
//           "ManufacturePart Number",
//           "Country of origin or manufacturing or country of assembly in case of imported products",
//           "Name and address of the manufacturer",
//           "Where manufacturer is not the packer,name and address of packer",
//           "Name and address of the importer if the product is being imported",
//           "Sellora’s tax code which decides the goods and services tax for the listing",
//           "Tax Rate",
//           "Fullfilment of FA listings will be managed by Sellora",
//           "Information on who will ship the item to the customer",
//           "ProductLength",
//           "Product LengthUnit", 
//           "Width Of Product",
//           "Product Width Unit",
    
//           "Height Of Product",
//           "Product Height Unit",
    
//           "Weight Of Product",
//           "Product Weight Unit",
    
//           "Length Of Package",
//           "Package LengthUnit",
    
//           "Width Of Package",
//           "Package Width Unit",
    
//           "Height Of Package",
//           "Package Height Unit",
    
//           "Weight Of Package",
//           "Packag eWeight Unit",
    
//           `Image Details - Front View - A full front view of a t shirt is a photo of the shirt from the front, with the model standing straight. It shows the fit, design details, and style. | Minimum Resolution - 1600x1600 | Please see the Image Guidelines sheet for more details.`,
//           `Image Details - Front View - A full front view of a t shirt is a photo of the shirt from the front, with the model standing straight. It shows the fit, design details, and style. | Minimum Resolution - 1600x1600 | Please see the Image Guidelines sheet for more details.`,
//           `Image Details - Front View - A full front view of a t shirt is a photo of the shirt from the front, with the model standing straight. It shows the fit, design details, and style. | Minimum Resolution - 1600x1600 | Please see the Image Guidelines sheet for more details.`,
//           `Image Details - Front View - A full front view of a t shirt is a photo of the shirt from the front, with the model standing straight. It shows the fit, design details, and style. | Minimum Resolution - 1600x1600 | Please see the Image Guidelines sheet for more details.`,
//           `Image Details - Front View - A full front view of a t shirt is a photo of the shirt from the front, with the model standing straight. It shows the fit, design details, and style. | Minimum Resolution - 1600x1600 | Please see the Image Guidelines sheet for more details.`,
//           `Image Details - Front View - A full front view of a t shirt is a photo of the shirt from the front, with the model standing straight. It shows the fit, design details, and style. | Minimum Resolution - 1600x1600 | Please see the Image Guidelines sheet for more details.`,
//           `Image Details - Front View - A full front view of a t shirt is a photo of the shirt from the front, with the model standing straight. It shows the fit, design details, and style. | Minimum Resolution - 1600x1600 | Please see the Image Guidelines sheet for more details.`,
//           `Image Details - Front View - A full front view of a t shirt is a photo of the shirt from the front, with the model standing straight. It shows the fit, design details, and style. | Minimum Resolution - 1600x1600 | Please see the Image Guidelines sheet for more details.`,
          
    
            
// ];



// export const variantDetailsInField = [ 
          
//           // variant Fields 
//           "Product Id",
//           "ProductId Type",
//           `Seller SKU ID is the identification number maintained by seller to keep track of SKUs. This will be mapped with Sellora Serial Number.`,
//           `Inactive listings are not available for buyers on Sellora`,
//           `Maximum retail price of the product`,
//           "Price at which you want to sell this listing",
//           "Price at which you want to sell this listing for B2B",
//           "The maximum stock quantity you can update is 5000 units per location. For MinOQ listings, the limit is 5000 × MinOQ per location.",
//           "USD/INR",
//           "Condition Type",
//           "Expire Date", 
//           "Yes/No",
//            `Image Details - Front View - A full front view of a t shirt is a photo of the shirt from the front, with the model standing straight. It shows the fit, design details, and style. | Minimum Resolution - 1600x1600 | Please see the Image Guidelines sheet for more details.`,
//           `Image Details - Front View - A full front view of a t shirt is a photo of the shirt from the front, with the model standing straight. It shows the fit, design details, and style. | Minimum Resolution - 1600x1600 | Please see the Image Guidelines sheet for more details.`,
//           `Image Details - Front View - A full front view of a t shirt is a photo of the shirt from the front, with the model standing straight. It shows the fit, design details, and style. | Minimum Resolution - 1600x1600 | Please see the Image Guidelines sheet for more details.`,
//           `Image Details - Front View - A full front view of a t shirt is a photo of the shirt from the front, with the model standing straight. It shows the fit, design details, and style. | Minimum Resolution - 1600x1600 | Please see the Image Guidelines sheet for more details.`,
//           `Image Details - Front View - A full front view of a t shirt is a photo of the shirt from the front, with the model standing straight. It shows the fit, design details, and style. | Minimum Resolution - 1600x1600 | Please see the Image Guidelines sheet for more details.`,
//           `Image Details - Front View - A full front view of a t shirt is a photo of the shirt from the front, with the model standing straight. It shows the fit, design details, and style. | Minimum Resolution - 1600x1600 | Please see the Image Guidelines sheet for more details.`,
//           `Image Details - Front View - A full front view of a t shirt is a photo of the shirt from the front, with the model standing straight. It shows the fit, design details, and style. | Minimum Resolution - 1600x1600 | Please see the Image Guidelines sheet for more details.`,
                 
// ];


// export const thiredFormField = [
//     "Contains Liquid Contents",
//     "Liquid Volume",
//     "Liquid Volume Unit",

//     "Is The Item Heat Sensitive",
//     "Heat Sensitive Instructions",
//     "Is The LiquidProduc tDouble Sealed",
//     "Product Double Sealed Instructions",

//     "Dangerous Goods Regulations",
//     "Safety Warning",
//     "Has Written Warranty",
//     "Product Is Or Contains An Electronic Component",
//     "Product Is Or Contains This Battery Type",
//     "Are Batteries Included",
//     "Battery Cell Composition"
// ]

// export const thiredFormFieldDataTypes = [
//      "Single-Text",
//     "Single-Text",
//     "Single-Text",

//     "Single-Text",
//     "Single-Text",
//     "Single-Text",
//     "Single-Text",

//     "Single-Text",
//     "Single-Text",
//     "Single-Text",
//     "Single-Text",
//     "Single-Text",
//     "Single-Text",
//     "Single-Text"
// ]


// export const thiredFormfillExampleField = [
//     "",
//     "",
//     "",

//     "",
//     "",
//     "",
//     "",

//     "",
//     "",
//     "",
//     "",
//     "",
//     "",
//     ""
// ]


// export const thiredFormDetailsInField = [
//     "Yes/No",
//     "",
//     "",

//     "",
//     "",
//     "",
//     "",

//     "",
//     "",
//     "",
//     "",
//     "",
//     "",
//     ""
// ]




//   const thresholdDataField = [
//     "Quantity Base Discount Type",
//     "Threshold Levels1 Unit",
//     "Threshold Levels1 Discount",

//     "Threshold Levels2 Unit",
//     "Threshold Levels2 Discount",

//     "Threshold Levels3 Unit",
//     "Threshold Levels3 Discount",

//     "Threshold Levels4 Unit",
//     "Threshold Levels4 Discount",

//     "Threshold Levels5 Unit",
//     "Threshold Levels5 Discount",
//   ]