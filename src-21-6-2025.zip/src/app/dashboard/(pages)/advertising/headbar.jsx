import React from 'react'

function Headbar() {
  return (
    <div>Headbar</div>
  )
}

export default Headbar