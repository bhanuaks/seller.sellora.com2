import React from 'react'
import WalletPaymentReceipt from './SellerWalletPaymentReceipt'

function page() {
  return (
    <WalletPaymentReceipt />
  )
}

export default page