'use client'
import React, { useEffect, useState } from 'react'
import SearchBox from '../SearchBox';
import { baseUrl } from '@/Http/helper';
import LeftMobileSideBarLearn from '../LeftMobileSideBarLearn';
import LeftSideBarLearn from '../LeftSideBarLearn';
import { usePathname } from 'next/navigation';
import { initAccordion } from '../menuListeners';
import Link from 'next/link';


function page() {

const pathname = usePathname();

   useEffect(() => {
    const cleanUp = initAccordion();
    return cleanUp;
  }, []);

  return (
    <>
  
<div className="notification_breadcomb_rts-navigation-area-breadcrumb d-lg-none d-md-block">
    <div className="container">
      <div className="row">
        <div className="col-lg-12">
          <div className="notification_breadcomb mb-6">
            <ul>
              <li>
                <a href="#"> Help</a>{" "}
              </li>
              <li>
                <Link href={`${baseUrl}dashboard/help-center/sellora-learn`}> Learn</Link>{" "}
              </li>
              
              <li>
                <a href="#" className="active_002">
                  List Products In Bulk
                </a>{" "}
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>




  {/* ==================new-code================== */}
  <div className="container">
    <div className="row">
      
       <LeftSideBarLearn />
      
      <div className="col-lg-9">
        

<div className="notification_breadcomb_rts-navigation-area-breadcrumb d-lg-block d-none">
  <div className="container">
    <div className="row">
      <div className="col-lg-12">
        <div className="notification_breadcomb mb-6">
          <ul>
            <li>
              <a href="#">Help </a>{" "}
            </li>
            <li>
              <Link href={`${baseUrl}dashboard/help-center/sellora-learn`}>Learn </Link>{" "}
            </li>
            
            <li>
              <a href="#" className="active_002">
                 List Products In Bulk
              </a>{" "}
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>



        {/* ==============mobile-menu-filter-open========================= */}
        <LeftMobileSideBarLearn />
        {/* ===================mobile-menu-filter-end==================== */}
        <div className="main-content_10-7">
          <SearchBox />
          <div className="featured_10-7">
            <div className="new_content_11">
              

             
  

<>
  <p>
    <strong>List Products In Bulk</strong>
  </p>
  <div className="video-container">
    <iframe
      width={560}
      height={315}
      src="https://www.youtube.com/embed/uHlMNI9E-PU?si=Yy2eOeyn1sM_khTb"
      title="YouTube video player"
      frameBorder={0}
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
      referrerPolicy="strict-origin-when-cross-origin"
      allowFullScreen=""
    />
  </div>
  <p>
    <strong>Introduction</strong>
  </p>
  <p>
    Learn how to list all your products at once with bulk upload on Sellora.
  </p>
  <p>
    <strong>What You'll Learn in This Video</strong>
  </p>
  <ul>
    <li>Access and download the bulk listing template.</li>
    <li>&nbsp;Fill in product data like title, brand, price, stock.</li>
    <li>&nbsp;Submit the completed file for bulk upload.&nbsp;</li>
    <li>Track listing status and fix any errors.&nbsp;</li>
    <li>Save time by uploading hundreds of products at once.</li>
  </ul>
  <p />
  <div className="container">
    <div className="ic-box py-5 ">
      <h3 className="pb-3" style={{ textAlign: "center" }}>
        Tell us what you think
      </h3>
      <div className="ic">
        <i className="fa-regular like fa-thumbs-up" />
        <i className="fa-regular dislike fa-thumbs-down" />
      </div>
    </div>
  </div>
</>









            </div>
          </div>
          {/* ==============getting-started-section=open================ */}
        </div>
        
      </div>
    </div>
  </div>
</>

  )
}

export default page