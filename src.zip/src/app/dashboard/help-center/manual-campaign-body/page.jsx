'use client'
import React, { useEffect, useState } from 'react'
import SearchBox from '../SearchBox';
import { baseUrl } from '@/Http/helper';
import LeftMobileSideBarLearn from '../LeftMobileSideBarLearn';
import LeftSideBarLearn from '../LeftSideBarLearn';
import { usePathname } from 'next/navigation';
import { initAccordion } from '../menuListeners';
import Link from 'next/link';


function page() {

const pathname = usePathname();

   useEffect(() => {
    const cleanUp = initAccordion();
    return cleanUp;
  }, []);

  return (
    <>
  
<div className="notification_breadcomb_rts-navigation-area-breadcrumb d-lg-none d-md-block">
    <div className="container">
      <div className="row">
        <div className="col-lg-12">
          <div className="notification_breadcomb mb-6">
            <ul>
              <li>
                <a href="#"> Help</a>{" "}
              </li>
              <li>
                <Link href={`${baseUrl}dashboard/help-center/sellora-learn`}> Learn</Link>{" "}
              </li>
              
              <li>
                <a href="#" className="active_002">
                  Manual Campaign
                </a>{" "}
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>




  {/* ==================new-code================== */}
  <div className="container">
    <div className="row">
      
       <LeftSideBarLearn />
      
      <div className="col-lg-9">
        

<div className="notification_breadcomb_rts-navigation-area-breadcrumb d-lg-block d-none">
  <div className="container">
    <div className="row">
      <div className="col-lg-12">
        <div className="notification_breadcomb mb-6">
          <ul>
            <li>
              <a href="#">Help </a>{" "}
            </li>
            <li>
              <Link href={`${baseUrl}dashboard/help-center/sellora-learn`}>Learn </Link>{" "}
            </li>
            
            <li>
              <a href="#" className="active_002">
                 Manual Campaign
              </a>{" "}
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>



        {/* ==============mobile-menu-filter-open========================= */}
        <LeftMobileSideBarLearn />
        {/* ===================mobile-menu-filter-end==================== */}
        <div className="main-content_10-7">
          <SearchBox />
          <div className="featured_10-7">
            <div className="new_content_11">
              

             
  


<>
  <p>
    <strong>Manual Campaign</strong>
  </p>
  <div className="video-container">
    <iframe
      width={560}
      height={315}
      src="https://www.youtube.com/embed/lC92JJdWXv0?si=DveJjCmoI3Sfa4Od"
      title="YouTube video player"
      frameBorder={0}
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
      referrerPolicy="strict-origin-when-cross-origin"
      allowFullScreen=""
    />
  </div>
  <p>
    <strong>Introduction</strong>
  </p>
  <p>
    Learn how to create manual ad campaigns to boost your product visibility on
    Sellora.
  </p>
  <p>
    <strong>What You'll Learn in This Video</strong>
  </p>
  <ul>
    <li>&nbsp;What a manual campaign.</li>
    <li>Create manual ad campaigns step-by-step.&nbsp;</li>
    <li>Improve visibility and increase sales with manual ads.&nbsp;</li>
  </ul>
  <p />
  <div className="container">
    <div className="ic-box py-5 ">
      <h3 className="pb-3" style={{ textAlign: "center" }}>
        Tell us what you think
      </h3>
      <div className="ic">
        <i className="fa-regular like fa-thumbs-up" />
        <i className="fa-regular dislike fa-thumbs-down" />
      </div>
    </div>
  </div>
</>









            </div>
          </div>
          {/* ==============getting-started-section=open================ */}
        </div>
        
      </div>
    </div>
  </div>
</>

  )
}

export default page