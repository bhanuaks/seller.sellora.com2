import React from 'react'
import UserStatusEmail from './UserStatusEmail'


function page() {
  return (
    <UserStatusEmail />
  )
}

export default page